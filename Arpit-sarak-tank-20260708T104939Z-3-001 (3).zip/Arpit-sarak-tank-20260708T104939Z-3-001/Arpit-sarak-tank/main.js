let mainSection = document.getElementById("data-list-wrapper");

// pitch
let pitchTitleInput = document.getElementById("pitch-title");
let pitchImageInput = document.getElementById("pitch-image");
let pitchCategoryInput = document.getElementById("pitch-category");
let pitchfounderInput = document.getElementById("pitch-founder");
let pitchPriceInput = document.getElementById("pitch-price");
let pitchCreateBtn = document.getElementById("add-pitch");

// Update pitch
let updatePitchIdInput = document.getElementById("update-pitch-id");
let updatePitchTitleInput = document.getElementById("update-pitch-title");
let updatePitchImageInput = document.getElementById("update-pitch-image");
let updatePitchfounderInput = document.getElementById("update-pitch-founder");
let updatePitchCategoryInput = document.getElementById("update-pitch-category");
let updatePitchPriceInput = document.getElementById("update-pitch-price");
let updatePitchBtn = document.getElementById("update-pitch");

//Update price
let updatePricePitchId = document.getElementById("update-price-pitch-id");
let updatePricePitchPrice = document.getElementById("update-price-pitch-price");
let updatePricePitchPriceButton = document.getElementById("update-price-pitch");

//sort and filter
let sortAtoZBtn = document.getElementById("sort-low-to-high");
let sortZtoABtn = document.getElementById("sort-high-to-low");
let filterFood = document.getElementById("filter-Food");
let filterElectronics = document.getElementById("filter-Electronics");
let filterPersonalCare = document.getElementById("filter-Personal-Care");

//Search by title/founder

let searchBySelect = document.getElementById("search-by-select");
let searchByInput = document.getElementById("search-by-input");
let searchByButton = document.getElementById("search-by-button");

// Problem 1. List of pitches on page load [3}


let arr = [];  //data

function fetchData() {
  fetch("http://localhost:3000/pitches")
    .then((res) => res.json())
    .then((data) => {DisplayData(data), arr = data})
    .catch((err) => console.log(err));
}
fetchData();

function DisplayData(data) {
  let store = data.map(
    (el, index) =>
      `<div>
        <h3 data-id=${el.id}> id : ${el.id} </h3>
        <img src="${el.image}" height="200px" width="200px">
        <h2>Founder : ${el.founder}</h2>
        <p>Description : ${el.description} </p>
        <p>Title : ${el.title} </p>
        <p> Price : ${el.price} </p>
        <p>category : ${el.category} </p>
        <a href="#" class="card-link" data-id=${el.id}> Edit </a> &nbsp;&nbsp;&nbsp;
        <button class="card-button" data-id=${el.id}> Delete </button>
        </div> `,
  );
  mainSection.innerHTML = store.join(" ");
}


pitchCreateBtn.addEventListener("click", () => {
  let dataObj = {
    title: pitchTitleInput.value,
    image: pitchImageInput.value,
    category: pitchCategoryInput.value,
    founder: pitchfounderInput.value,
    price: pitchPriceInput.value,
  };

  // console.log(dataObj)

  fetch("http://localhost:3000/pitches", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(dataObj), // Converts JS object to JSON string
  });
});

document.addEventListener("click", (e) => {
  if (e.target.classList.contains("card-button")) //class
  {
    let id = e.target.dataset.id; //id

    fetch(`http://localhost:3000/pitches/${id}`, {
      method: "DELETE",
      headers: {
        "Content-Type": "application/json",
      },
    })
      .then((response) => response.json())
      .then((data) => console.log("Deleted successfully:", data))
      .catch((error) => console.error("Error:", error));
  }
});

document.addEventListener("click", (e) => {
  if (e.target.classList.contains("card-link")) {
    let updatedid = e.target.dataset.id;

    fetch(`http://localhost:3000/pitches/${updatedid}`)
      .then((res) => res.json())
      .then((data) => {
        ((updatePitchIdInput.value = data.id),
          (updatePitchTitleInput.value = data.title),
          (updatePitchImageInput.value = data.image),
          (updatePitchfounderInput.value = data.founder));
        ((updatePitchCategoryInput.value = data.category),
          (updatePitchPriceInput.value = data.price));
      })
      .catch((err) => console.log(err));
  }
});

updatePitchBtn.addEventListener("click", (e) => {
  let updateData = {
    id: updatePitchIdInput.value,
    title: updatePitchTitleInput.value,
    image: updatePitchImageInput.value,
    founder: updatePitchfounderInput.value,
    category: updatePitchCategoryInput.value,
  };

  fetch(`http://localhost:3000/pitches/${updateData.id}`, {
    method: "PUT",
    headers: {
      "Content-Type": "application/json", // Tells the server to expect JSON
    },
    body: JSON.stringify(updateData),
  });
});

sortAtoZBtn.addEventListener('click',()=>{
  
  let ans = arr.sort((a,b)=> a.price - b.price)
  DisplayData(ans)
})

sortZtoABtn.addEventListener('click',()=>{

let ans = arr.sort((a,b)=> b.price - a.price)
 DisplayData(ans)
})

filterFood.addEventListener('click',()=>{
    let abc = arr.filter((el)=>(el.category == 'Food'))
    DisplayData(abc)
})